﻿using LoggerUtility.Interfaces;
using System;
using System.IO;

namespace LoggerUtility
{
    public class Logger : ILogger
    {
        private readonly string _filePath;

        /// <summary>
        /// Constructor
        /// </summary>
        public Logger()
        {
            _filePath = "Logs\\DataExtractorLogs.txt";
            if (!Directory.Exists("Logs"))
            {
                Directory.CreateDirectory("Logs");
            }
            if (!File.Exists(_filePath))
            {
                File.Create(_filePath);
            }
        }

        /// <summary>
        /// Logs the information.
        /// </summary>
        /// <param name="message"></param>
        public void LogInformation(string message)
        {
            Log(message, "INFO");
        }

        /// <summary>
        /// Logs the Error.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="ex"></param>
        public void LogError(string message, Exception ex = null)
        {
            var errorMessage = ex != null ? $"{message} - Exception: {ex.Message}" : message;
            Log(errorMessage, "ERROR");
        }

        /// <summary>
        /// Append text in log file.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="level"></param>
        private void Log(string message, string level)
        {
            var logMessage = $"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} [{level}] {message}";
            File.AppendAllText(_filePath, logMessage + Environment.NewLine);
        }
    }
}
