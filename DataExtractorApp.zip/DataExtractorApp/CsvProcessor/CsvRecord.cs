﻿using CsvHelper.Configuration;

namespace CsvProcessor
{
    public class CsvRecord
    {
        // Represents the ISIN field in the CSV file
        public string ISIN { get; set; }

        // Represents the CFICode field in the CSV file
        public string CFICode { get; set; }

        // Represents the Venue field in the CSV file
        public string Venue { get; set; }

        // Represents the extracted Contract Size (from the PriceMultiplier in AlgoParams)
        public string ContractSize { get; set; }
    }
}
