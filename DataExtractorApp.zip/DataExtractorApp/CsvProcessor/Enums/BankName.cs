﻿namespace CsvProcessor.Enums
{
    public enum BankName
    {
        None = 0,
        Barclays = 1
    }
}
