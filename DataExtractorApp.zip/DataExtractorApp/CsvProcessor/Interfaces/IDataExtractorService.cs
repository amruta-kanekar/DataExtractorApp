﻿using System.Collections.Generic;

namespace CsvProcessor.Interfaces
{
    public interface IDataExtractorService
    {
        List<CsvRecord> ProcessCsv(string bankName, string filePath);

        bool SaveCsv(List<CsvRecord> records, string outputFilePath);

        string ExtractContractSize(string algoParams);
    }
}
