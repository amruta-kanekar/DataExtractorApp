﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvProcessor.Enums;
using CsvProcessor.Interfaces;
using LoggerUtility.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;

namespace CsvProcessor
{
    /// <summary>
    /// Service for extracting data from CSV files and processing it according to bank-specific logic.
    /// </summary>
    public class DataExtractorService : IDataExtractorService
    {
        private ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        public DataExtractorService(ILogger logger)
        {
            this._logger = logger;
        }

        /// <summary>
        /// Processes a CSV file based on the specified bank name and returns a list of CSV records.
        /// </summary>
        /// <param name="bankName">Name of the bank to process the file for.</param>
        /// <param name="filePath">Path to the CSV file to process.</param>
        /// <returns>List of processed CSV records.</returns>
        public List<CsvRecord> ProcessCsv(string bankName, string filePath)
        {
            return ProcessCsvFromFile(bankName, filePath);
        }

        /// <summary>
        /// Processes a CSV file by determining the bank type and applying the corresponding processing logic.
        /// </summary>
        /// <param name="bankName">Name of the bank to process the file for.</param>
        /// <param name="filePath">Path to the CSV file to process.</param>
        /// <returns>List of processed CSV records.</returns>
        private List<CsvRecord> ProcessCsvFromFile(string bankName, string filePath)
        {
            // Initialize a list to hold the processed records
            List<CsvRecord> records = null;

            try
            {
                this._logger?.LogInformation("ProcessCsvFromFile | Entered");
                // Attempt to parse the bank name into an enum
                Enum.TryParse<BankName>(bankName, true, out BankName bank);

                // Process the file based on the bank type
                switch (bank)
                {
                    case BankName.Barclays:
                        records = ProcessBarclaysInputFile(filePath);
                        break;

                    // Add more cases for other banks as needed

                    default:
                        break;
                }
                this._logger?.LogInformation("ProcessCsvFromFile | Exited");
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
            }

            return records;
        }

        /// <summary>
        /// Processes a Barclays CSV file, extracting relevant fields and adding them to the records list.
        /// </summary>
        /// <param name="filePath">Path to the Barclays CSV file.</param>
        /// <param name="records">List to store the processed records.</param>
        private List<CsvRecord> ProcessBarclaysInputFile(string filePath)
        {
            List<CsvRecord> records = new List<CsvRecord>();
            try
            {
                this._logger?.LogInformation("ProcessBarclaysInputFile | Entered");
                // Set up CSV configuration with culture and missing field handling
                var csvConfig = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    MissingFieldFound = null // Ignore missing fields
                };

                // Open the CSV file and read its contents
                using (var reader = new StreamReader(filePath))
                using (var csv = new CsvReader(reader, csvConfig))
                {
                    // Read through the file line by line
                    bool first = csv.Read(); // Read the first line (can be used if needed)

                    // Read the header
                    bool sec = csv.Read(); // Read the second line (can be used if needed)
                    bool head = csv.ReadHeader(); // Read the header line
                    while (csv.Read()) // Loop through each record in the CSV
                    {
                        // Create a new CsvRecord and populate its fields
                        var record = new CsvRecord();
                        record.ISIN = csv.GetField("ISIN");
                        record.CFICode = csv.GetField("CFICode");
                        record.Venue = csv.GetField("Venue");
                        record.ContractSize = ExtractContractSize(csv.GetField("AlgoParams"));

                        // Add the populated record to the list
                        records.Add(record);
                    }
                }
                this._logger?.LogInformation("ProcessBarclaysInputFile | Exited");
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
            }
            return records;
        }

        /// <summary>
        /// Extracts the contract size from the 'AlgoParams' field using a regular expression.
        /// </summary>
        /// <param name="algoParams">The 'AlgoParams' field value.</param>
        /// <returns>The extracted contract size, or an empty string if not found.</returns>
        public string ExtractContractSize(string algoParams)
        {
            try
            {
                this._logger?.LogInformation("ExtractContractSize | Entered");
                if (!string.IsNullOrEmpty(algoParams))
                {
                    // Define the regex pattern to capture the PriceMultiplier value
                    var pattern = @"PriceMultiplier:(\d+(\.\d+)?)";
                    var match = Regex.Match(algoParams, pattern);

                    // Check if the match is successful and return the captured value
                    if (match.Success)
                    {
                        return match.Groups[1].Value;
                    }
                }
                this._logger?.LogInformation("ExtractContractSize | Exited");
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
            }
            return string.Empty; // Return empty if no match is found
        }

        /// <summary>
        /// Saves the processed CSV records to a specified output file path.
        /// </summary>
        /// <param name="records">List of records to save.</param>
        /// <param name="outputFilePath">Path to save the CSV file.</param>
        /// <returns>True if the save operation was successful, false otherwise.</returns>
        public bool SaveCsv(List<CsvRecord> records, string outputFilePath)
        {
            try
            {
                this._logger?.LogInformation("SaveCsv | Entered");

                // Write the records to the specified output file
                using (var writer = new StreamWriter(outputFilePath))
                using (var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture)))
                {
                    csv.WriteRecords(records);
                }
                this._logger?.LogInformation("SaveCsv | Exited");
                return true; // Return true if save was successful
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
                return false;
            }
        }
    }
}
