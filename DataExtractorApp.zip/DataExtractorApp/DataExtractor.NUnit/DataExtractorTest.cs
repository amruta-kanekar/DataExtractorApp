﻿using CsvProcessor;
using CsvProcessor.Interfaces;
using LoggerUtility.Interfaces;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.IO;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace DataExtractor.NUnit
{
    [TestFixture]
    public class DataExtractorTest
    {
        private Mock<ILogger> _mockLogger;
        private IDataExtractorService _dataExtractorService;
        private string _tempFilePath;

        [SetUp]
        public void SetUp()
        {
            // Initialize mock logger and the service
            _mockLogger = new Mock<ILogger>();
            _dataExtractorService = new DataExtractorService(_mockLogger.Object);
        }

        [Test]
        public void ProcessCsv_ValidBankName_ReturnsRecords()
        {
            // Arrange
            var csvContent = "Time Zone\n" +
                             "ISIN,CFICode,Venue,AlgoParams\n" +
                             "ABC123,EQ,NYSE,PriceMultiplier:100\n" +
                             "DEF456,EQ,NASDAQ,PriceMultiplier:200";

            CreateTempCsvFile(csvContent);

            // Act
            var records = _dataExtractorService.ProcessCsv("Barclays", _tempFilePath);

            // Assert
            Assert.AreEqual(2, records.Count);
            Assert.AreEqual("ABC123", records[0].ISIN);
            Assert.AreEqual("100", records[0].ContractSize);
            Assert.AreEqual("DEF456", records[1].ISIN);
            Assert.AreEqual("200", records[1].ContractSize);
        }

        [Test]
        public void ProcessCsv_InvalidBankName_ReturnsEmptyList()
        {
            // Arrange
            var csvContent = "Time Zone\n" + 
                             "ISIN,CFICode,Venue,AlgoParams\n" +
                             "ABC123,EQ,NYSE,PriceMultiplier:100";

            CreateTempCsvFile(csvContent);

            // Act
            var records = _dataExtractorService.ProcessCsv("InvalidBank", _tempFilePath);

            // Assert
            Assert.IsNull(records);
        }

        [Test]
        public void ProcessCsvFromFile_BarclaysFile_ProcessesCorrectly()
        {
            // Arrange
            var csvContent = "Time Zone\n" + 
                             "ISIN,CFICode,Venue,AlgoParams\n" +
                             "ABC123,EQ,NYSE,PriceMultiplier:100\n" +
                             "XYZ789,EQ,LSE,PriceMultiplier:150";

            CreateTempCsvFile(csvContent);

            // Act
            var records = _dataExtractorService.ProcessCsv("Barclays", _tempFilePath);

            // Assert
            Assert.AreEqual(2, records.Count);
            Assert.AreEqual("100", records[0].ContractSize);
            Assert.AreEqual("150", records[1].ContractSize);
        }

        [Test]
        public void ExtractContractSize_ValidAlgoParams_ReturnsContractSize()
        {
            // Arrange
            var algoParams = "SomeData;PriceMultiplier:250;MoreData";

            // Act
            var contractSize = _dataExtractorService.ExtractContractSize(algoParams);

            // Assert
            Assert.AreEqual("250", contractSize);
        }

        [Test]
        public void ExtractContractSize_InvalidAlgoParams_ReturnsEmptyString()
        {
            // Arrange
            var algoParams = "SomeData;NoMultiplierHere;MoreData";

            // Act
            var contractSize = _dataExtractorService.ExtractContractSize(algoParams);

            // Assert
            Assert.AreEqual(string.Empty, contractSize);
        }

        [Test]
        public void SaveCsv_ValidRecords_SavesSuccessfully()
        {
            // Arrange
            var records = new List<CsvRecord>
            {
                new CsvRecord { ISIN = "ABC123", CFICode = "EQ", Venue = "NYSE", ContractSize = "100" },
                new CsvRecord { ISIN = "XYZ789", CFICode = "EQ", Venue = "LSE", ContractSize = "150" }
            };

            var tempFilePath = Path.GetTempFileName();

            // Act
            var result = _dataExtractorService.SaveCsv(records, tempFilePath);

            // Assert
            Assert.IsTrue(result);
            Assert.IsTrue(File.Exists(tempFilePath));

        }

        [Test]
        public void SaveCsv_ExceptionThrown_ReturnsFalse()
        {
            // Arrange
            var records = new List<CsvRecord>();
            var tempFilePath = "/invalid_path/file.csv"; // Invalid path to trigger an exception

            // Act
            var result = _dataExtractorService.SaveCsv(records, tempFilePath);

            // Assert
            Assert.IsFalse(result);
        }

        // Helper method to create a temporary CSV file for testing
        private void CreateTempCsvFile(string content)
        {
            _tempFilePath = Path.Combine(Path.GetTempPath(), "temp.csv");
            File.WriteAllText(_tempFilePath, content);
        }

        [TearDown]
        public void TearDown()
        {
            // Cleanup
            if (File.Exists(_tempFilePath))
            {
                File.Delete(_tempFilePath); 
            }
        }
    }
}
