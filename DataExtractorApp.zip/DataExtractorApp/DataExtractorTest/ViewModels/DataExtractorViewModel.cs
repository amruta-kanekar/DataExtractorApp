﻿using CsvProcessor.Interfaces;
using LoggerUtility.Interfaces;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Input;

namespace DataExtractorTest.ViewModels
{
    public class DataExtractorViewModel : INotifyPropertyChanged
    {
        #region Variable Declaration
        // Event for property change notification
        public event PropertyChangedEventHandler PropertyChanged;

        private readonly IDataExtractorService _csvManager;
        private string _bankName;
        private string _filePath;
        private string _errorMessage; 
        private ILogger _logger;
        #endregion

        #region Properties and Commands
        // Selected bank
        public string BankName
        {
            get { return _bankName; }
            set
            {
                _bankName = value;
                OnPropertyChanged(nameof(BankName));
                ((RelayCommand)ProcessCommand).RaiseCanExecuteChanged();
            }
        }

        // File path of the selected CSV
        public string FilePath
        {
            get { return _filePath; }
            set
            {
                _filePath = value;
                OnPropertyChanged(nameof(FilePath));
                ((RelayCommand)ProcessCommand).RaiseCanExecuteChanged();
            }
        }

        public string ErrorMessage
        {
            get { return _errorMessage; }
            set
            {
                _errorMessage = value;
                OnPropertyChanged(nameof(ErrorMessage));
            }
        }

        // Command to browse for a file
        public ICommand BrowseCommand { get; }

        // Command to process the file
        public ICommand ProcessCommand { get; }
        #endregion

        #region Constructor
        // Constructor
        public DataExtractorViewModel(ILogger logger,  IDataExtractorService csvManager)
        {
            this._logger = logger;
            this._csvManager = csvManager;
            this.ErrorMessage = string.Empty;

            // Initialize commands
            BrowseCommand = new RelayCommand(BrowseFile);
            ProcessCommand = new RelayCommand(ProcessFile, CanProcessFile);

        } 
        #endregion

        #region Methods
        // Browse for a file
        private void BrowseFile(object parameter)
        {
            try
            {
                this._logger?.LogInformation("BrowseFile Entered");
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == true)
                {
                    if (openFileDialog.FileName.EndsWith(".csv"))
                    {
                        FilePath = openFileDialog.FileName;
                        ErrorMessage = string.Empty;
                    }
                    else
                    {
                        ErrorMessage = "File format not supported.";
                    }
                }
                this._logger?.LogInformation("BrowseFile Exited");
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
            }
        }

        // Check if processing is allowed (only when file is selected and bank is chosen)
        private bool CanProcessFile(object parameter)
        {
            return !string.IsNullOrEmpty(FilePath) && !string.IsNullOrEmpty(BankName);
        }

        // Process the selected file
        private void ProcessFile(object parameter)
        {
            try
            {
                this._logger?.LogInformation("ProcessFile Entered");
                if (FilePath.EndsWith(".csv"))
                {
                    // Here, you would load and process the CSV using the selected bank's schema
                    var records = _csvManager.ProcessCsv(BankName, FilePath);

                    if (records != null)
                    {
                        //// After processing, you would save the output file
                        string outputFileName = Path.ChangeExtension(FilePath, "Extracted.csv"); ;
                        if (_csvManager.SaveCsv(records, outputFileName))
                        {
                            MessageBox.Show("File Extracted Successfully at location : " + outputFileName, "Success");
                            BankName = string.Empty;
                            FilePath = string.Empty;
                        } 
                    }
                    else
                    {
                        MessageBox.Show("Invalid Bank Name.");
                    }
                }
                else
                {
                    MessageBox.Show("File format not supported.");
                }
                this._logger?.LogInformation("ProcessFile Exited");
            }
            catch (Exception ex)
            {
                this._logger?.LogError(ex.Message, ex);
            }
        }

        // Helper method to raise the PropertyChanged event
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        } 
        #endregion
    }
}
