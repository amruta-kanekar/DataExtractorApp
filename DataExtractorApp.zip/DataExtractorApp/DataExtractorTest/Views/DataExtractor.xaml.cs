﻿using CsvProcessor;
using DataExtractorTest.ViewModels;
using System.Windows;

namespace DataExtractorTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class DataExtractor : Window
    {
        public DataExtractor(DataExtractorViewModel dataExtractorViewModel)
        {
            InitializeComponent();
            this.DataContext = dataExtractorViewModel;
        }
    }
}
