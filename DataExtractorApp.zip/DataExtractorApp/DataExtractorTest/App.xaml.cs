﻿using DataExtractorTest.ViewModels;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Windows;
using CsvProcessor;
using CsvProcessor.Interfaces;
using LoggerUtility.Interfaces;
using LoggerUtility;

namespace DataExtractorTest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private IHost _host;
        public App()
        {
            _host = Host.CreateDefaultBuilder()
                .ConfigureServices((context, services) =>
                {
                    ServiceBaseRegistry.RegisterServices(services);
                    // Register other services or viewmodels if necessary
                    services.AddSingleton<ILogger, Logger>();
                    services.AddSingleton<DataExtractorViewModel>();
                    services.AddSingleton<DataExtractor>(); // Register the main window
                })
                .Build();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var mainWindow = _host.Services.GetRequiredService<DataExtractor>();
            mainWindow.Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _host.Dispose();
            base.OnExit(e);
        }
    }

    public static class ServiceBaseRegistry
    {
        public static void RegisterServices(IServiceCollection services)
        {
            // Register your services here
            services.AddSingleton<IDataExtractorService, DataExtractorService>();

            // Add other services as needed
        }
    }
}
